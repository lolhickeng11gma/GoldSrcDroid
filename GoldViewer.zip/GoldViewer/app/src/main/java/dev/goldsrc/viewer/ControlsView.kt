package dev.goldsrc.viewer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/** Прозрачный оверлей: стик, кнопки вверх/вниз/ускорение, свайп по экрану = взгляд. */
class ControlsView(
    ctx: Context,
    private val st: ControlState,
    private val prefs: SharedPreferences
) : View(ctx) {

    var edit = false
        set(v) { field = v; resetInput(); invalidate() }
    var scale = 1f
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val names = arrayOf("stick", "up", "down", "fast")
    private val labels = arrayOf("", "▲", "▼", "x3")
    private val defX = floatArrayOf(0.16f, 0.91f, 0.91f, 0.79f)
    private val defY = floatArrayOf(0.68f, 0.52f, 0.80f, 0.80f)
    private val px = FloatArray(4)
    private val py = FloatArray(4)
    private val roles = HashMap<Int, Int>()
    private val lastX = HashMap<Int, Float>()
    private val lastY = HashMap<Int, Float>()
    private var knobX = 0f
    private var knobY = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init { load() }

    fun load() {
        for (i in 0..3) {
            px[i] = prefs.getFloat(names[i] + "X", defX[i])
            py[i] = prefs.getFloat(names[i] + "Y", defY[i])
        }
        scale = prefs.getFloat("scale", 1f)
    }

    fun resetLayout() {
        val e = prefs.edit()
        for (i in 0..3) { px[i] = defX[i]; py[i] = defY[i]; e.remove(names[i] + "X"); e.remove(names[i] + "Y") }
        e.apply()
        invalidate()
    }

    private fun saveLayout() {
        val e = prefs.edit()
        for (i in 0..3) { e.putFloat(names[i] + "X", px[i]); e.putFloat(names[i] + "Y", py[i]) }
        e.apply()
    }

    private fun cx(i: Int) = px[i] * width
    private fun cy(i: Int) = py[i] * height
    private fun radius(i: Int) = (if (i == 0) 62f else 34f) * d * scale

    private fun resetInput() {
        roles.clear(); lastX.clear(); lastY.clear()
        st.mx = 0f; st.my = 0f; st.up = false; st.down = false; st.fast = false
        knobX = 0f; knobY = 0f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE ->
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> for (id in roles.keys.toList()) up(id)
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        var role = 4
        for (i in 0..3) {
            val r = radius(i) * (if (i == 0) 1.5f else 1.25f)
            if (hypot(x - cx(i), y - cy(i)) <= r) { role = i; break }
        }
        if (edit && role == 4) return
        roles[id] = role; lastX[id] = x; lastY[id] = y
        if (!edit) when (role) {
            0 -> moveStick(x, y)
            1 -> st.up = true
            2 -> st.down = true
            3 -> st.fast = true
        }
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val role = roles[id] ?: return
        if (edit) {
            if (role < 4) {
                px[role] = (x / width).coerceIn(0.04f, 0.96f)
                py[role] = (y / height).coerceIn(0.06f, 0.94f)
                invalidate()
            }
            return
        }
        when (role) {
            0 -> moveStick(x, y)
            4 -> {
                st.addLook(x - (lastX[id] ?: x), y - (lastY[id] ?: y))
                lastX[id] = x; lastY[id] = y
            }
        }
    }

    private fun up(id: Int) {
        val role = roles.remove(id) ?: return
        lastX.remove(id); lastY.remove(id)
        if (edit) { saveLayout(); return }
        when (role) {
            0 -> { st.mx = 0f; st.my = 0f; knobX = 0f; knobY = 0f }
            1 -> st.up = false
            2 -> st.down = false
            3 -> st.fast = false
        }
        invalidate()
    }

    private fun moveStick(x: Float, y: Float) {
        val r = radius(0)
        var dx = x - cx(0)
        var dy = y - cy(0)
        val len = hypot(dx, dy)
        if (len > r) { dx = dx / len * r; dy = dy / len * r }
        knobX = dx; knobY = dy
        st.mx = dx / r
        st.my = -dy / r
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val line = if (edit) 0xFFFFD54F.toInt() else 0xFFFFFFFF.toInt()
        for (i in 0..3) {
            val r = radius(i)
            paint.style = Paint.Style.FILL
            paint.color = 0x33FFFFFF
            c.drawCircle(cx(i), cy(i), r, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * d
            paint.color = (line and 0x00FFFFFF) or 0x99000000.toInt()
            c.drawCircle(cx(i), cy(i), r, paint)
            if (i == 0) {
                paint.style = Paint.Style.FILL
                paint.color = 0x88FFFFFF.toInt()
                c.drawCircle(cx(0) + knobX, cy(0) + knobY, r * 0.38f, paint)
            } else {
                paint.style = Paint.Style.FILL
                paint.color = 0xCCFFFFFF.toInt()
                paint.textSize = r * 0.8f
                paint.textAlign = Paint.Align.CENTER
                c.drawText(labels[i], cx(i), cy(i) + paint.textSize * 0.33f, paint)
            }
        }
        if (edit) {
            paint.style = Paint.Style.FILL
            paint.color = 0xFFFFD54F.toInt()
            paint.textSize = 16f * d
            paint.textAlign = Paint.Align.CENTER
            c.drawText("Перетащите стик и кнопки куда удобно, затем «Готово»", width / 2f, height * 0.12f, paint)
        }
    }
}
