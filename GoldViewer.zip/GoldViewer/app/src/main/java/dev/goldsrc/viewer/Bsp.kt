package dev.goldsrc.viewer

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

class MipTex(val name: String, val w: Int, val h: Int, val argb: IntArray?)
class TexRef(val name: String, val w: Int, val h: Int, val embedded: MipTex?)
class Group(val tex: Int, val start: Int, val count: Int)
class MapData(
    val verts: FloatArray,
    val groups: List<Group>,
    val texs: List<TexRef>,
    val spawn: FloatArray,
    val yaw: Float,
    val faces: Int
)

private class FloatList {
    var a = FloatArray(1 shl 14)
    var n = 0
    fun add(v: Float) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n++] = v
    }
}

/** Парсер BSP v30 (GoldSrc) и WAD3. Рисуем только мир (model 0). */
object Bsp {
    private val SKIP = setOf(
        "sky", "clip", "hint", "skip", "null", "origin",
        "aaatrigger", "bevel", "solidhint", "noclip"
    )

    private fun wrap(d: ByteArray) = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)

    fun parseMip(b: ByteBuffer, off: Int): MipTex? {
        if (off < 0 || off + 40 > b.limit()) return null
        var len = 0
        val nb = ByteArray(16)
        for (i in 0 until 16) nb[i] = b.get(off + i)
        while (len < 16 && nb[len] != 0.toByte()) len++
        val name = String(nb, 0, len, Charsets.ISO_8859_1).lowercase()
        val w = b.getInt(off + 16)
        val h = b.getInt(off + 20)
        if (w <= 0 || h <= 0 || w > 4096 || h > 4096) return MipTex(name, 0, 0, null)
        val o0 = b.getInt(off + 24)
        if (o0 <= 0) return MipTex(name, w, h, null) // внешняя текстура (в WAD)
        val o3 = b.getInt(off + 36)
        val pal = off + o3 + (w / 8) * (h / 8) + 2
        if (off + o0 + w * h > b.limit() || pal + 768 > b.limit()) return MipTex(name, w, h, null)
        val trans = name.startsWith("{")
        val argb = IntArray(w * h)
        for (i in 0 until w * h) {
            val idx = b.get(off + o0 + i).toInt() and 255
            if (trans && idx == 255) {
                argb[i] = 0
            } else {
                val p = pal + idx * 3
                val r = b.get(p).toInt() and 255
                val g = b.get(p + 1).toInt() and 255
                val bl = b.get(p + 2).toInt() and 255
                argb[i] = (255 shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        return MipTex(name, w, h, argb)
    }

    fun parseWad(data: ByteArray): Map<String, MipTex> {
        val out = HashMap<String, MipTex>()
        if (data.size < 12) return out
        val b = wrap(data)
        if (b.getInt(0) != 0x33444157) return out // "WAD3"
        val n = b.getInt(4)
        val tab = b.getInt(8)
        for (i in 0 until n) {
            val e = tab + i * 32
            if (e < 0 || e + 32 > data.size) break
            val pos = b.getInt(e)
            val type = b.get(e + 12).toInt()
            val comp = b.get(e + 13).toInt()
            if (type == 0x43 && comp == 0) {
                val mt = parseMip(b, pos)
                if (mt != null && mt.argb != null) out[mt.name] = mt
            }
        }
        return out
    }

    fun parse(data: ByteArray): MapData {
        val b = wrap(data)
        val ver = b.getInt(0)
        if (ver != 30) throw IllegalArgumentException("Нужен BSP версии 30 (GoldSrc), а тут: $ver")
        fun lo(i: Int) = b.getInt(4 + i * 8)
        fun ll(i: Int) = b.getInt(8 + i * 8)

        // Текстуры
        val tOff = lo(2)
        val nTex = b.getInt(tOff)
        val texs = ArrayList<TexRef>()
        for (i in 0 until nTex) {
            val o = b.getInt(tOff + 4 + i * 4)
            val mt = if (o > 0) parseMip(b, tOff + o) else null
            val w = if ((mt?.w ?: 0) > 0) mt!!.w else 64
            val h = if ((mt?.h ?: 0) > 0) mt!!.h else 64
            texs.add(TexRef(mt?.name ?: "missing$i", w, h, mt?.takeIf { it.argb != null }))
        }

        val vOff = lo(3)
        val tiOff = lo(6)
        val fOff = lo(7)
        val eOff = lo(12)
        val sOff = lo(13)
        val mOff = lo(14)
        val first = b.getInt(mOff + 56)
        val num = b.getInt(mOff + 60)

        val lists = HashMap<Int, FloatList>()
        var faceCount = 0
        for (fi in first until first + num) {
            val fo = fOff + fi * 20
            val firstEdge = b.getInt(fo + 4)
            val nEdges = b.getShort(fo + 8).toInt() and 0xFFFF
            val ti = b.getShort(fo + 10).toInt() and 0xFFFF
            if (nEdges < 3) continue
            val to = tiOff + ti * 40
            val mi = b.getInt(to + 32)
            if (mi < 0 || mi >= texs.size) continue
            val tr = texs[mi]
            if (tr.name in SKIP) continue

            val pts = FloatArray(nEdges * 3)
            for (k in 0 until nEdges) {
                val se = b.getInt(sOff + (firstEdge + k) * 4)
                val vi = if (se >= 0) b.getShort(eOff + se * 4).toInt() and 0xFFFF
                else b.getShort(eOff + (-se) * 4 + 2).toInt() and 0xFFFF
                pts[k * 3] = b.getFloat(vOff + vi * 12)
                pts[k * 3 + 1] = b.getFloat(vOff + vi * 12 + 4)
                pts[k * 3 + 2] = b.getFloat(vOff + vi * 12 + 8)
            }
            // нормаль -> простое затенение (лайтмапы пока не реализованы)
            val e1x = pts[3] - pts[0]; val e1y = pts[4] - pts[1]; val e1z = pts[5] - pts[2]
            val e2x = pts[6] - pts[0]; val e2y = pts[7] - pts[1]; val e2z = pts[8] - pts[2]
            var nx = e1y * e2z - e1z * e2y
            var ny = e1z * e2x - e1x * e2z
            var nz = e1x * e2y - e1y * e2x
            val nl = sqrt(nx * nx + ny * ny + nz * nz)
            if (nl > 1e-6f) { nx /= nl; ny /= nl; nz /= nl }
            val shade = 0.45f + 0.55f * abs(nx * 0.3f + ny * 0.2f + nz * 0.9f).coerceAtMost(1f)

            val sx = b.getFloat(to); val sy = b.getFloat(to + 4); val sz = b.getFloat(to + 8); val so = b.getFloat(to + 12)
            val tx = b.getFloat(to + 16); val ty = b.getFloat(to + 20); val tz = b.getFloat(to + 24); val tOf = b.getFloat(to + 28)

            val lst = lists.getOrPut(mi) { FloatList() }
            fun emit(k: Int) {
                val x = pts[k * 3]; val y = pts[k * 3 + 1]; val z = pts[k * 3 + 2]
                lst.add(x); lst.add(y); lst.add(z)
                lst.add((x * sx + y * sy + z * sz + so) / tr.w)
                lst.add((x * tx + y * ty + z * tz + tOf) / tr.h)
                lst.add(shade)
            }
            for (k in 1 until nEdges - 1) { emit(0); emit(k); emit(k + 1) }
            faceCount++
        }

        var total = 0
        for (l in lists.values) total += l.n
        val verts = FloatArray(total)
        val groups = ArrayList<Group>()
        var pos = 0
        for (key in lists.keys.sorted()) {
            val l = lists[key]!!
            System.arraycopy(l.a, 0, verts, pos, l.n)
            groups.add(Group(key, pos / 6, l.n / 6))
            pos += l.n
        }

        // Точка спавна из сущностей
        val entStr = String(data, lo(0), ll(0).coerceAtLeast(0), Charsets.ISO_8859_1)
        var spawn = floatArrayOf(
            (b.getFloat(mOff) + b.getFloat(mOff + 12)) / 2,
            (b.getFloat(mOff + 4) + b.getFloat(mOff + 16)) / 2,
            (b.getFloat(mOff + 8) + b.getFloat(mOff + 20)) / 2
        )
        var yaw = 0f
        var found = 0
        val block = Regex("\\{([^}]*)\\}")
        val kv = Regex("\"([^\"]*)\"\\s+\"([^\"]*)\"")
        for (m in block.findAll(entStr)) {
            val ent = HashMap<String, String>()
            for (k in kv.findAll(m.groupValues[1])) ent[k.groupValues[1]] = k.groupValues[2]
            val cn = ent["classname"]
            val pr = if (cn == "info_player_start") 2 else if (cn == "info_player_deathmatch") 1 else 0
            val org = ent["origin"]
            if (pr > found && org != null) {
                val p = org.trim().split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
                if (p.size == 3) {
                    spawn = floatArrayOf(p[0], p[1], p[2] + 17f)
                    yaw = ent["angle"]?.toFloatOrNull() ?: 0f
                    found = pr
                }
            }
        }
        return MapData(verts, groups, texs, spawn, yaw, faceCount)
    }
}
