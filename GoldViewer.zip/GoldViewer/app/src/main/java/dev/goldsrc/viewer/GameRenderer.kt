package dev.goldsrc.viewer

import android.graphics.Bitmap
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class GameRenderer(private val ctl: ControlState) : GLSurfaceView.Renderer {
    private var pending: MapData? = null
    @Volatile private var wads: Map<String, MipTex> = emptyMap()
    @Volatile private var texDirty = false

    private var map: MapData? = null
    private var uploadNeeded = false
    private var prog = 0
    private var aPos = 0; private var aUv = 0; private var aShade = 0
    private var uMvp = 0; private var uTex = 0
    private var vbo = 0
    private var texIds = IntArray(0)

    private var x = 0f; private var y = 0f; private var z = 0f
    private var yaw = 0f; private var pitch = 0f
    private var aspect = 1f
    private var last = 0L
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)

    @Synchronized fun setMap(m: MapData) { pending = m }
    @Synchronized private fun takePending(): MapData? { val p = pending; pending = null; return p }
    fun setWads(w: Map<String, MipTex>) { wads = w; texDirty = true }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val vs = """
            uniform mat4 uMVP;
            attribute vec3 aPos; attribute vec2 aUv; attribute float aShade;
            varying vec2 vUv; varying float vShade;
            void main() { vUv = aUv; vShade = aShade; gl_Position = uMVP * vec4(aPos, 1.0); }
        """.trimIndent()
        val fs = """
            precision mediump float;
            uniform sampler2D uTex; varying vec2 vUv; varying float vShade;
            void main() {
                vec4 c = texture2D(uTex, vUv);
                if (c.a < 0.5) discard;
                gl_FragColor = vec4(c.rgb * vShade, 1.0);
            }
        """.trimIndent()
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(prog)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUv = GLES20.glGetAttribLocation(prog, "aUv")
        aShade = GLES20.glGetAttribLocation(prog, "aShade")
        uMvp = GLES20.glGetUniformLocation(prog, "uMVP")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        GLES20.glClearColor(0.05f, 0.07f, 0.12f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        vbo = 0; texIds = IntArray(0) // контекст пересоздан — старые id недействительны
        uploadNeeded = map != null
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        aspect = w.toFloat() / h.coerceAtLeast(1)
    }

    override fun onDrawFrame(gl: GL10?) {
        takePending()?.let {
            map = it
            x = it.spawn[0]; y = it.spawn[1]; z = it.spawn[2]
            yaw = it.yaw; pitch = 0f
            uploadNeeded = true
        }
        val m = map
        if (m != null && uploadNeeded) { upload(m); uploadNeeded = false; texDirty = false }
        if (m != null && texDirty) { texDirty = false; rebuildTextures(m) }

        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceAtMost(0.1f)
        last = now
        update(dt)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (m == null || vbo == 0) return

        val yr = Math.toRadians(yaw.toDouble()); val pr = Math.toRadians(pitch.toDouble())
        val fx = (cos(pr) * cos(yr)).toFloat(); val fy = (cos(pr) * sin(yr)).toFloat(); val fz = sin(pr).toFloat()
        Matrix.perspectiveM(proj, 0, 75f, aspect, 4f, 16000f)
        Matrix.setLookAtM(view, 0, x, y, z, x + fx, y + fy, z + fz, 0f, 0f, 1f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, 0)
        GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 24, 12)
        GLES20.glEnableVertexAttribArray(aShade)
        GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, 24, 20)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        for (g in m.groups) {
            if (g.tex >= texIds.size) continue
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texIds[g.tex])
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, g.start, g.count)
        }
    }

    private fun update(dt: Float) {
        val look = ctl.takeLook()
        val k = 0.15f * ctl.sens
        yaw -= look[0] * k
        pitch -= look[1] * k * (if (ctl.invert) -1f else 1f)
        pitch = pitch.coerceIn(-89f, 89f)
        val yr = Math.toRadians(yaw.toDouble()); val pr = Math.toRadians(pitch.toDouble())
        val fx = (cos(pr) * cos(yr)).toFloat(); val fy = (cos(pr) * sin(yr)).toFloat(); val fz = sin(pr).toFloat()
        val sp = ctl.speed * (if (ctl.fast) 3f else 1f) * dt
        val mx = ctl.mx; val my = ctl.my
        x += fx * my * sp + sin(yr).toFloat() * mx * sp
        y += fy * my * sp - cos(yr).toFloat() * mx * sp
        z += fz * my * sp + ((if (ctl.up) 1f else 0f) - (if (ctl.down) 1f else 0f)) * sp
    }

    private fun upload(m: MapData) {
        if (vbo != 0) GLES20.glDeleteBuffers(1, intArrayOf(vbo), 0)
        if (texIds.isNotEmpty()) GLES20.glDeleteTextures(texIds.size, texIds, 0)
        val fb = ByteBuffer.allocateDirect(m.verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(m.verts); fb.position(0)
        val id = IntArray(1)
        GLES20.glGenBuffers(1, id, 0)
        vbo = id[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, m.verts.size * 4, fb, GLES20.GL_STATIC_DRAW)
        texIds = IntArray(m.texs.size)
        GLES20.glGenTextures(texIds.size, texIds, 0)
        rebuildTextures(m)
    }

    private fun rebuildTextures(m: MapData) {
        val w = wads
        for (i in m.texs.indices) {
            val ref = m.texs[i]
            val mt = ref.embedded ?: w[ref.name]
            val bmp = if (mt?.argb != null && mt.w > 0)
                Bitmap.createBitmap(mt.argb, mt.w, mt.h, Bitmap.Config.ARGB_8888)
            else checker(ref.name)
            val pw = pot(bmp.width); val ph = pot(bmp.height)
            val s = if (pw != bmp.width || ph != bmp.height) Bitmap.createScaledBitmap(bmp, pw, ph, false) else bmp
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texIds[i])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, s, 0)
            GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
            if (s !== bmp) bmp.recycle()
            s.recycle()
        }
    }

    private fun pot(v: Int): Int { var p = 1; while (p < v) p = p shl 1; return p }

    private fun checker(name: String): Bitmap {
        val h = name.hashCode()
        val c1 = Color.rgb(100 + (h and 0x3f), 100 + ((h shr 6) and 0x3f), 100 + ((h shr 12) and 0x3f))
        val c2 = Color.rgb(Color.red(c1) / 2, Color.green(c1) / 2, Color.blue(c1) / 2)
        val px = IntArray(64 * 64) { i -> if (((i % 64) / 16 + (i / 64) / 16) % 2 == 0) c1 else c2 }
        return Bitmap.createBitmap(px, 64, 64, Bitmap.Config.ARGB_8888)
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }
}
