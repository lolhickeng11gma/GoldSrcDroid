package dev.goldsrc.viewer

/** Общее состояние ввода: UI-поток пишет, GL-поток читает. */
class ControlState {
    @Volatile var mx = 0f
    @Volatile var my = 0f
    @Volatile var up = false
    @Volatile var down = false
    @Volatile var fast = false
    @Volatile var sens = 1f
    @Volatile var speed = 400f
    @Volatile var invert = false
    private var lx = 0f
    private var ly = 0f

    @Synchronized fun addLook(dx: Float, dy: Float) { lx += dx; ly += dy }
    @Synchronized fun takeLook(): FloatArray {
        val r = floatArrayOf(lx, ly)
        lx = 0f; ly = 0f
        return r
    }
}
