package dev.goldsrc.viewer

import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val st = ControlState()
    private lateinit var gl: GLSurfaceView
    private lateinit var renderer: GameRenderer
    private lateinit var controls: ControlsView
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private lateinit var doneBtn: Button
    private val normalBtns = ArrayList<View>()
    private val wadMap = HashMap<String, MipTex>()
    private var lastMap: MapData? = null

    private val pickBsp = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadBsp(uri)
    }
    private val pickWad = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) loadWads(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ctl", Context.MODE_PRIVATE)
        st.sens = prefs.getFloat("sens", 1f)
        st.speed = prefs.getFloat("speed", 400f)
        st.invert = prefs.getBoolean("invert", false)

        renderer = GameRenderer(st)
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 0, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        controls = ControlsView(this, st, prefs)

        status = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 12f
            setShadowLayer(3f, 0f, 0f, 0xFF000000.toInt())
            setPadding(16, 8, 16, 8)
            text = "Нажмите BSP и выберите карту (.bsp) из вашей копии Half-Life"
        }

        fun btn(t: String, f: () -> Unit) = Button(this@MainActivity).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bBsp = btn("BSP") { pickBsp.launch(arrayOf("*/*")) }
        val bWad = btn("WAD") { pickWad.launch(arrayOf("*/*")) }
        val bCtl = btn("Управление") { showSettings() }
        doneBtn = btn("Готово") { setEdit(false) }.apply { visibility = View.GONE }
        for (b in listOf(bBsp, bWad, bCtl)) { bar.addView(b); normalBtns.add(b) }
        bar.addView(doneBtn)

        val root = FrameLayout(this)
        root.addView(gl)
        root.addView(controls)
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        setContentView(root)
    }

    private fun setEdit(on: Boolean) {
        controls.edit = on
        doneBtn.visibility = if (on) View.VISIBLE else View.GONE
        for (b in normalBtns) b.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun readAll(uri: Uri): ByteArray =
        contentResolver.openInputStream(uri)!!.use { it.readBytes() }

    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun summary(m: MapData): String {
        val missing = m.texs.count { it.embedded == null && it.name !in wadMap }
        return "Граней: ${m.faces}, текстур: ${m.texs.size}" +
            (if (missing > 0) " (без текстуры: $missing — добавьте WAD)" else "")
    }

    private fun loadBsp(uri: Uri) {
        say("Загрузка карты…")
        Thread {
            try {
                val m = Bsp.parse(readAll(uri))
                lastMap = m
                renderer.setMap(m)
                say(summary(m))
            } catch (t: Throwable) {
                say("Ошибка: ${t.message ?: t.javaClass.simpleName}")
            }
        }.start()
    }

    private fun loadWads(uris: List<Uri>) {
        say("Загрузка WAD…")
        Thread {
            try {
                for (u in uris) wadMap.putAll(Bsp.parseWad(readAll(u)))
                renderer.setWads(HashMap(wadMap))
                say("WAD: текстур ${wadMap.size}. " + (lastMap?.let { summary(it) } ?: ""))
            } catch (t: Throwable) {
                say("Ошибка WAD: ${t.message ?: t.javaClass.simpleName}")
            }
        }.start()
    }

    private fun seek(
        parent: LinearLayout, title: String, min: Int, max: Int, cur: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ) {
        val tv = TextView(this).apply { text = title + ": " + fmt(cur) }
        val sb = SeekBar(this).apply { this.max = max - min; progress = cur - min }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = title + ": " + fmt(v)
                onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv); parent.addView(sb)
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        seek(box, "Чувствительность взгляда", 10, 300, (st.sens * 100).toInt(), { "%.2f".format(it / 100f) }) {
            st.sens = it / 100f; prefs.edit().putFloat("sens", st.sens).apply()
        }
        seek(box, "Скорость полёта", 100, 1500, st.speed.toInt(), { "$it" }) {
            st.speed = it.toFloat(); prefs.edit().putFloat("speed", st.speed).apply()
        }
        seek(box, "Размер кнопок", 60, 160, (controls.scale * 100).toInt(), { "$it%" }) {
            controls.scale = it / 100f; prefs.edit().putFloat("scale", controls.scale).apply()
        }
        box.addView(CheckBox(this).apply {
            text = "Инвертировать взгляд по вертикали"
            isChecked = st.invert
            setOnCheckedChangeListener { _, v -> st.invert = v; prefs.edit().putBoolean("invert", v).apply() }
        })
        val dlg = AlertDialog.Builder(this).setTitle("Управление")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK", null).create()
        box.addView(Button(this).apply {
            text = "Расставить кнопки вручную"
            setOnClickListener { dlg.dismiss(); setEdit(true) }
        })
        box.addView(Button(this).apply {
            text = "Сбросить расположение"
            setOnClickListener { controls.resetLayout() }
        })
        dlg.show()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onPause() { super.onPause(); gl.onPause() }
    override fun onResume() { super.onResume(); gl.onResume() }
}
